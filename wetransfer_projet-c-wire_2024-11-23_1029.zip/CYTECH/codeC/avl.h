#ifndef AVL_H
#define AVL_H

// Définition de la structure pour un nœud AVL
typedef struct NoeudAVL {
    char *cle;               // Clé (par exemple : identifiant de station)
    int valeur;              // Valeur associée (par exemple : consommation)
    struct NoeudAVL *gauche; // Fils gauche
    struct NoeudAVL *droit;  // Fils droit
    int hauteur;             // Hauteur du nœud
} NoeudAVL;

// Prototypes des fonctions AVL
NoeudAVL *inserer_avl(NoeudAVL *noeud, const char *cle, int valeur);
void afficher_avl(NoeudAVL *racine);
void liberer_avl(NoeudAVL *racine);

#endif
