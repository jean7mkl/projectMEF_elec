#include <stdio.h>
#include <stdlib.h>
#include "avl.h"

int main() {
    // Initialiser l'arbre AVL
    NoeudAVL *arbre = NULL;

    // Ajouter des nœuds à l'arbre
    arbre = inserer_avl(arbre, "station1", 50);
    arbre = inserer_avl(arbre, "station2", 30);
    arbre = inserer_avl(arbre, "station3", 70);

    // Afficher l'arbre (parcours en ordre)
    printf("Arbre AVL :\n");
    afficher_avl(arbre);

    // Libérer la mémoire de l'arbre
    liberer_avl(arbre);

    return 0;
}
