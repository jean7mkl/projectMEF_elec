#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "avl.h"
#include "io.h"

NoeudAVL *charger_csv_dans_avl(const char *nom_fichier) {
    printf("Chargement des données depuis %s...\n", nom_fichier);

    FILE *fichier = fopen(nom_fichier, "r");
    if (!fichier) {
        perror("Erreur d'ouverture du fichier");
        return NULL;
    }

    NoeudAVL *arbre = NULL;
    char ligne[256]; // Augmenté pour s'assurer que toutes les données peuvent être lues.
    char cle[128];
    char cle_unique[128];
    char id_centrale[128];
    char type_station[128];
    char type_consommateur[128];
    int capacity, load, other;

    // Lecture ligne par ligne
    while (fgets(ligne, sizeof(ligne), fichier)) {
        // Supprimer le saut de ligne final, si présent
        ligne[strcspn(ligne, "\n")] = '\0';

      if (strcmp(ligne, "type_station,type_consommateur,id_centrale,capacity,load,other") == 0) {
      continue; // Ignorer l'en-tête
      }

        // Extraire les colonnes depuis la ligne
        if (sscanf(ligne, "%127[^,],%127[^,],%127[^,],%d,%d",
           type_station, type_consommateur, id_centrale, &capacity, &load) == 5) {
            // Construire une clé unique si nécessaire
            snprintf(cle_unique, sizeof(cle_unique), "%s_%s_%s", type_station, type_consommateur, id_centrale);

            // Insérer dans l'AVL, par exemple utiliser capacity comme valeur
            arbre = inserer_avl(arbre, cle, capacity);
        } else {
            fprintf(stderr, "Format de ligne invalide : %s\n", ligne);
        }
    }

    fclose(fichier);
    return arbre;
}



void ecrire_avl(FILE *fichier, NoeudAVL *racine) {
    if (racine != NULL) {
        ecrire_avl(fichier, racine->gauche);
        fprintf(fichier, "%s,%d\n", racine->cle, racine->valeur);
        ecrire_avl(fichier, racine->droit);
    }
}



int generer_fichier_sortie(const char *nom_fichier, NoeudAVL *racine) {
    printf("Génération du fichier de sortie %s...\n", nom_fichier);

    FILE *fichier = fopen(nom_fichier, "w");
    if (!fichier) {
        perror("Erreur d'ouverture du fichier");
        return 0;
    }

    // Écrire les données dans le fichier
    ecrire_avl(fichier, racine);

    fclose(fichier);
    return 1;
}
