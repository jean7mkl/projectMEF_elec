#!/bin/bash

# Définition du fichier de log
LOG_FILE="execution.log"
exec > >(tee -a "$LOG_FILE") 2>&1

# Vérification des arguments
if [[ "$1" == "--help" || "$1" == "-h" ]]; then
    echo "Usage: $0 <chemin_csv> <type_station> <type_consommateur> [<id_centrale>] [--sort] [--keep-tmp] [--summary]"
    echo "OPTIONS:"
    echo "  <chemin_csv>      Chemin du fichier CSV d'entrée."
    echo "  <type_station>    Type de station à traiter : hvb, hva ou lv."
    echo "  <type_consommateur> Type de consommateur : comp, indiv, all."
    echo "  [<id_centrale>]   (Optionnel) Identifiant de la centrale à filtrer."
    echo "  -h, --help        Affiche cette aide."
    echo "  --sort            Trie les données filtrées par capacity."
    echo "  --keep-tmp        Conserve les fichiers temporaires après exécution."
    echo "  --summary         Affiche un résumé sans exécuter le programme C."
    exit 0
fi

# Chronométrage global
START_TIME=$(date +%s)

# Vérification des dépendances
if ! command -v mingw32-make &> /dev/null; then
    echo "Erreur : make n'est pas installé ou introuvable."
    exit 1
fi

if ! command -v grep &> /dev/null; then
    echo "Erreur : grep n'est pas installé ou introuvable."
    exit 1
fi

# Extraction des arguments
chemin_csv="$1"
type_station="$2"
type_consommateur="$3"
id_centrale="${4:-}"

# Gestion des options
keep_tmp=false
sort_data=false
for arg in "$@"; do
    if [[ "$arg" == "--keep-tmp" ]]; then
        keep_tmp=true
    elif [[ "$arg" == "--sort" ]]; then
        sort_data=true
    fi
done

# Vérification du fichier d'entrée
if [[ ! -f "$chemin_csv" ]]; then
    echo "Erreur : Le fichier $chemin_csv n'existe pas."
    exit 1
fi

if [[ ! -s "$chemin_csv" ]]; then
    echo "Erreur : Le fichier $chemin_csv est vide."
    exit 1
fi

# Vérification des valeurs acceptées
if [[ "$type_station" != "hvb" && "$type_station" != "hva" && "$type_station" != "lv" ]]; then
    echo "Erreur : Type de station invalide ($type_station). Utiliser hvb, hva ou lv."
    exit 1
fi

if [[ "$type_consommateur" != "comp" && "$type_consommateur" != "indiv" && "$type_consommateur" != "all" ]]; then
    echo "Erreur : Type de consommateur invalide ($type_consommateur). Utiliser comp, indiv ou all."
    exit 1
fi

# Préparer le répertoire temporaire
mkdir -p tmp
fichier_filtre="tmp/filtered.csv"

# Filtrer les données
echo "Filtrage des données pour type_station=$type_station, type_consommateur=$type_consommateur, id_centrale=$id_centrale..."
grep -E "^$type_station," "$chemin_csv" | grep -E ",$type_consommateur," > "$fichier_filtre"

if [[ ! -f "$fichier_filtre" ]]; then
    echo "Erreur : Le fichier temporaire $fichier_filtre n'a pas été créé."
    exit 1
fi

echo "Contenu de $fichier_filtre après filtrage :"
cat "$fichier_filtre"

# Vérification après le premier filtrage
if [[ ! -s "$fichier_filtre" ]]; then
    echo "Erreur : Aucun résultat après le filtrage pour type_station=$type_station et type_consommateur=$type_consommateur."
    exit 1
fi

# Si un id_centrale est fourni, effectuer un second filtrage
if [[ -n "$id_centrale" ]]; then
    grep -E ",$id_centrale," "$fichier_filtre" > "tmp/filtered_with_id.csv"
    fichier_filtre="tmp/filtered_with_id.csv"
    if [[ ! -s "$fichier_filtre" ]]; then
        echo "Erreur : Aucun résultat après le filtrage par id_centrale ($id_centrale)."
        exit 1
    fi
fi

# Option de tri
if [[ "$sort_data" == true ]]; then
    echo "Tri des données filtrées par capacity..."
    sort -t, -k4 -n "$fichier_filtre" > tmp/sorted.csv
    mv tmp/sorted.csv "$fichier_filtre"
fi

# Compilation des fichiers source C si nécessaire
if [[ ! -f codeC/main ]]; then
    echo "Compilation des fichiers source C..."
    gcc -o codeC/main codeC/main.c codeC/io.c codeC/avl.c
    if [[ $? -ne 0 ]]; then
        echo "Erreur : Compilation échouée."
        exit 1
    fi
fi

# Exécution du programme C
echo "Exécution du programme C avec $fichier_filtre..."
./codeC/main "$fichier_filtre" 2>> "$LOG_FILE"
if [[ $? -ne 0 ]]; then
    echo "Erreur : Le programme C a échoué. Consultez $LOG_FILE pour plus de détails."
    exit 1
fi

# Nettoyage ou conservation des fichiers temporaires
if [[ "$keep_tmp" == true ]]; then
    echo "Option --keep-tmp activée, fichiers temporaires conservés."
else
    echo "Nettoyage des fichiers temporaires..."
    rm -rf tmp
fi

END_TIME=$(date +%s)
echo "Temps total d'exécution : $((END_TIME - START_TIME)) secondes"
